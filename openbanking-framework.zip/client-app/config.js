module.exports = {
  authServerBase: 'https://localhost:8443',
  resourceServerBase: 'http://localhost:8080'
};
# Developer Portal

## TPP Registration

Register your TPP by calling your API gateway's /register endpoint with:
- client_name
- redirect_uris
- jwks_uri

## Key Management

Place your client certificates in certs/:
- client.key
- client.crt
- ca.crt